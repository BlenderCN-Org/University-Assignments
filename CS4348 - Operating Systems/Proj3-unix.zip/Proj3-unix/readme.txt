To compile / run the program:
    javac Main.java
    java Main [file allocation type]

File Allocation Types:
    0 - Continuous Allocation
    1 - Chained Allocation
    2 - Indexed Allocation
