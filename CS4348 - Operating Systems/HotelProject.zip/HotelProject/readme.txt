To Run:

javac src/Main.java src/Classes/Bellhop.java src/Classes/Guest.java src/Classes/Clerk.java src/Globals/HotelHelper.java

cd src
java Main