function changehidden() {
    var d = document.getElementById("hiddenrow");
    if(d.style.visibility = "hidden") {
        d.style.visibility = "visible";
    } else if (d.style.visibility = "visible") {
        d.style.visibility = "hidden";
    }
}